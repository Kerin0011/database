CREATE VIEW view_commercial_monthly_sales AS
SELECT orders.id AS order_id, customers.name AS customer, order_details.quantity * order_details.historical_price AS revenue, orders.date_order
FROM orders
INNER JOIN customers ON orders.customer_id = customers.id
INNER JOIN order_details ON orders.id = order_details.order_id;

CREATE VIEW view_top_selling_products AS
SELECT products.name AS product, SUM(order_details.quantity) AS units_sold
FROM order_details
INNER JOIN products ON order_details.product_id = products.id
GROUP BY products.name
ORDER BY units_sold DESC;

DELIMITER 

CREATE PROCEDURE sp_get_customers(IN customer_id INT)
BEGIN
    IF p_customer_id IS NULL THEN
        SELECT id, name FROM customers;
    ELSE
        SELECT id, name FROM customers WHERE id = p_customer_id;
    END IF;
END 

DELIMITER ;